from .student import StudentModelViewSet
from .subject import SubjectModelViewSet
from .mark import MarkModelViewSet
